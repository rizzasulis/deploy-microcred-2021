#DEPLOYMENT MODEL TIME SERIES (PREDIKSI SAHAM)

Repository ini berisi semua file yang dibutuhkan untuk melakukan deployment model time series (prediksi saham)

Tugas Akhir ini merupakan tugas pada Pelatihan Microcredential Certification Associate Data Scientist tahun 2021. Daftar Nama Kelompok yang mengerjakan tugas akhir ini adalah: 

Rizza Sulistiana

Rahmah Miya Juwita

Salsabila Fasya 

Kelompok ini merupakan peserta pelatihan di Kelas UGM04, dengan host pelaksana adalah Universitas Gadjah Mada. 

